RUNEWAKE DRESSED NPCS + UNIVERSAL ANIMATION LIBRARY 2

Three NPC GLB models with selected clips retargeted by Quaternius skeleton bone name and rest-pose rotation.
Original base/outfit/animation packs are CC0 1.0: https://creativecommons.org/publicdomain/zero/1.0/
Models and animations by @Quaternius.

MIRA: Idle_FoldArms_Loop, Idle_No_Loop, Idle_Rail_Call, Walk_Carry_Loop, Yes, Farm_Harvest, Chest_Open
ORREN: Idle_FoldArms_Loop, Walk_Carry_Loop, TreeChopping_Loop, Yes, Sword_Regular_A, Sword_Heavy_Combo, Chest_Open
PIP: Idle_Lantern_Loop, Walk_Carry_Loop, Idle_Rail_Call, Yes, Consume, Farm_Harvest, Chest_Open

NOTE: Walk_Carry_Loop is for walking while holding an item; this pack does not include a conventional unarmed walk or normal idle loop. A basic walking cycle will be needed for patrol NPCs.

Roblox Open Cloud Model upload supports GLB files <= 20 MB, but IMPORTING a Model does NOT establish that individual AnimationClip assets have been published and can play. After importing, test the skeleton and clips in Roblox's Animation Clip Editor and publish Animation asset IDs. To animate NPCs in-game, add those IDs to their animator scripts and test in Roblox.

Current release files are prepared but have NOT been uploaded to Roblox or playtested.
